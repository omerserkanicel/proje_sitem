from flask import Flask, render_template,request, redirect, send_from_directory
from flask_sqlalchemy import SQLAlchemy
import time
from flask import Flask, render_template, request, jsonify
from imageai.Detection import VideoObjectDetection
from PIL import Image, ImageOps  # Install pillow instead of PIL
import numpy as np
from io import BytesIO
import IPython.display as display
from PIL import Image
import ses
import jsonify
import pandas as pd
import sys
import chardet
import tensorflow
from flask import Flask, render_template, request, send_file
from rembg import remove
from imageai.Detection import ObjectDetection
import os  
from werkzeug.utils import secure_filename
from flask import redirect, url_for
import cv2
import rembg
import torch
from torchvision import transforms
import io
import streamlit as st
from io import BytesIO
import tkinter as tk
from PIL import ImageTk
from http.server import SimpleHTTPRequestHandler
from socketserver import TCPServer
import base64
from PIL import Image, ImageDraw, ImageFont

app = Flask(__name__)




# Connecting SQLite

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///diary.db'

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Creating a DB

db = SQLAlchemy(app)

# Creating a DB table



#Assignment #1. Create a DB table

class Card(db.Model):

    # Creating the fields

    #id

    id = db.Column(db.Integer, primary_key=True)

    # Title

    title = db.Column(db.String(100), nullable=False)

    # Description

    subtitle = db.Column(db.String(300), nullable=False)

    # Text

    text = db.Column(db.Text, nullable=False)



    # Outputting the object and its id

    def __repr__(self):

        return f'<Card {self.id}>'

class User(db.Model):
    # Sütun oluşturma
    # id
    id = db.Column(db.Integer, primary_key=True, autoincrement = True)


    # Başlık
    email = db.Column(db.String(100), nullable=False)
    # Tanım
    password = db.Column(db.String(300), nullable=False)
    # Metin

# İlk sayfa
@app.route('/')
def baslangic():
    return render_template('baslangic.html')


# Form sonuçları
@app.route('/index', methods=['GET','POST'])
def index():
    if request.method == 'POST':
        # seçilen resmi almak

        selected_image = request.form.get('image-selector')


        # Görev #2. Metni almak
        textTop = request.form["textTop"]

        textBottom = request.form["textBottom"]


        # Görev #3. Metnin konumunu almak


        # Görev #3. Metnin rengini almak


        return render_template('index.html',
                               # Seçilen resmi görüntüleme
                               selected_image=selected_image,
                               # Görev #2. Metni görüntüleme
                               textTop=textTop,
                               textBottom=textBottom,
                               # Görev #3. Rengi görüntüleme

                               # Görev #3. Metnin konumunu görüntüleme

                               )
    else:
        # Varsayılan olarak ilk resmi görüntüleme
        return render_template('index.html', selected_image='logo1.svg')

@app.route('/index3', methods=['GET', 'POST'])
def index3():
    if request.method == 'POST':
        # Yüklenen resmi al
        uploaded_image = request.files['image']

        # Resmi kaydet
        image_path = "uploads/input_image.jpg"
        uploaded_image.save(image_path)

        # YOLOv3 modelini kullanarak nesne tespiti yap
        model_path = "yolov3 .pt"
        detector = ObjectDetection()
        detector.setModelTypeAsYOLOv3()
        detector.setModelPath(model_path)
        detector.loadModel()

        output_image_path = "uploads/output_image.jpg"
        detections = detector.detectObjectsFromImage(
            input_image=image_path,
            output_image_path=output_image_path,
            minimum_percentage_probability=30
        )

        # Sonucu göster
        return render_template('index3.html', input_image="uploads/input_image.jpg", output_image="uploads/output_image.jpg", detections=detections)

    return render_template('index3.html', input_image=None, output_image=None, detections=None)


@app.route('/login', methods=['GET','POST'])
def login():
        error = ''
        if request.method == 'POST':
            form_login = request.form['email']
            form_password = request.form['password']

            #Ödev #4. yetkilendirmeyi uygulamak
            kullanicilar_bilgileri = User.query.all()

            for kullanici in kullanicilar_bilgileri:
                if kullanici.email == form_login and kullanici.password == form_password:
                    return redirect("/günlük")
            return render_template("login.html")
        else:
            return render_template('login.html')



@app.route('/reg', methods=['GET','POST'])
def reg():
    if request.method == 'POST':
        login= request.form['email']
        sifre = request.form['password']

        #Ödev #3 Kullanıcı verilerinin veri tabanına kaydedilmesini sağlayın
        kullanici_girdi = User(email=login,password=sifre)
        db.session.add(kullanici_girdi)
        db.session.commit()

        return redirect('/login')

    else:
        return render_template('registration.html')


# İçerik sayfasını çalıştırma
@app.route('/günlük')
def günlük():
    # Veri tabanı girişlerini görüntüleme
    cards = Card.query.order_by(Card.id).all() 
    return render_template('günlük.html', cards=cards)

# Kayıt sayfasını çalıştırma
@app.route('/card/<int:id>')
def card(id):
    card = Card.query.get(id)

    return render_template('card.html', card=card)

# Giriş oluşturma sayfasını çalıştırma
@app.route('/create')
def create():
    return render_template('create_card.html')

# Giriş formu
@app.route('/form_create', methods=['GET','POST'])
def form_create():
    if request.method == 'POST':
        title =  request.form['title']
        subtitle =  request.form['subtitle']
        text =  request.form['text']

        # Veri tabanına gönderilecek bir nesne oluşturma
        card = Card(title=title, subtitle=subtitle, text=text)

        db.session.add(card)
        db.session.commit()
        
        return redirect('/günlük')
    else:
        return render_template('create_card.html')
@app.route('/portföy')
def portföy():
    return render_template('portföy.html')


# Dinamik beceriler
@app.route('/portföy', methods=['POST'])
def process_form():
    button_python = request.form.get('button_python')
    return render_template('portföy.html', button_python=button_python)

def analyze_frame(frame_number, output_array, output_count):
    # Bu fonksiyon, her bir çerçevedeki nesne tespiti sonuçlarını işler.
    # Sonuçları bir listeye ekleyerek daha sonra web sitesine gönderebilirsiniz.

    results = []

    for obj in output_array:
        result = {
            'frame_number': frame_number,
            'object': obj['name'],
            'percentage_probability': obj['percentage_probability'],
            'box_points': obj['box_points']
        }
        results.append(result)

   

detector = VideoObjectDetection()
model_path = "yolov3 .pt"
detector.setModelTypeAsYOLOv3()
detector.setModelPath(model_path)
detector.loadModel()

@app.route('/index4')
def index4():
    return render_template('index4.html')

@app.route('/upload1', methods=['POST'])
def upload1():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'})

    file = request.files['file']

    if file.filename == '':
        return jsonify({'error': 'No selected file'})

    if file:
        input_file_path = 'uploads/' + file.filename
        file.save(input_file_path)

        output_file_path = 'output_video.mp4'

        detections, output_frames_path = detector.detectObjectsFromVideo(
            input_file_path=input_file_path,
            output_file_path=output_file_path,
            frames_per_second=20,
            minimum_percentage_probability=30,
            return_detected_frame=True,
            log_progress=True
        )

        return jsonify({'output_file_path': output_file_path})

with app.app_context():
    db.create_all()
@app.route('/index5', methods=['GET', 'POST'])
def index5():
    if request.method == 'POST':
        # Yüklenen resmi al
        uploaded_image = request.files['image']

        # Resmi arka planından ayır
        input_data = uploaded_image.read()
        output_data = remove(input_data)

        # Ayırılmış resmi göster
        return send_file(BytesIO(output_data), mimetype='image/png', download_name='output.png')

    return render_template('index5.html')



@app.route('/index6', methods=['GET', 'POST'])
def index6():
    if request.method == 'POST':
        # Kullanıcının girdiği metni, punto, x ve y koordinatlarını ve resmi al
        user_text = request.form['user_text']
        font_size = int(request.form['font_size'])
        x_coordinate = int(request.form['x_coordinate'])
        y_coordinate = int(request.form['y_coordinate'])

        # Kullanıcının yüklediği resmi al
        uploaded_image = request.files['image']
        # Resmi aç
        image = Image.open(uploaded_image)

        # Metni ve başlangıç koordinatlarını tanımla
        text = user_text

        # Metni resme ekle
        draw = ImageDraw.Draw(image)
        font = ImageFont.truetype("arial.ttf", size=font_size)
        draw.text((x_coordinate, y_coordinate), text, fill="white", font=font)

        # Resmi base64 formatına dönüştür
        buffered = BytesIO()
        image.save(buffered, format="JPEG")
        image_base64 = base64.b64encode(buffered.getvalue()).decode('utf-8')

        return render_template('index6.html', image=image_base64, user_text=user_text, font_size=font_size,
                               x_coordinate=x_coordinate, y_coordinate=y_coordinate)

    return render_template('index6.html', image=None, user_text=None, font_size=None,
                           x_coordinate=None, y_coordinate=None)
@app.route('/index7', methods=['GET', 'POST'])
def index7():
    if request.method == 'POST':
        # Yüklenen resimleri al
        foreground_image = request.files['foreground_image']
        background_image = request.files['background_image']

        # Resimleri aç
        foreground = Image.open(foreground_image)
        background = Image.open(background_image)

        # Resimleri boyutlandırma (gerekiyorsa)
        background = background.resize(foreground.size)

        # Yeni arkaplanı ekleyin
        background.paste(foreground, (0, 0), foreground)

        # Sonucu base64 formatına dönüştür
        buffered = BytesIO()
        background.save(buffered, format="PNG")
        image_base64 = buffered.getvalue()

        # Sonucu gönder
        return send_file(BytesIO(image_base64), mimetype='image/png', download_name='output.png')

    return render_template('index7.html')
@app.route('/index8')
def index8():
    return render_template('index8.html')

@app.route('/detect_objects', methods=['POST'])
def detect_objects():
    video_path = request.form.get('video_path')
    output_path = request.form.get('output_path')

    detector = VideoObjectDetection()
    model_path = "yolov3 .pt"
    detector.setModelTypeAsYOLOv3()
    detector.setModelPath(model_path)
    detector.loadModel()

    detector.detectObjectsFromVideo(
        input_file_path=video_path,
        output_file_path=output_path,
        frames_per_second=20,
        minimum_percentage_probability=30,
        return_detected_frame=True,
        log_progress=True
    )

    return "Object detection completed. Check the output video."



if __name__ == '__main__':
    app.run(debug=True)